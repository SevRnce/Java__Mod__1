/**
 * 
 */
/**
 * 
 */
public class Print { 
    public static void main(String[] args) { 
    	System.out.println("First Name: Moxxi");
    	System.out.println("Last Name: Gemstone");
    	System.out.println("Address: 69 Morningwood St.");
    	System.out.println("City: Salt Lake City");
    	System.out.println("Zip Code: 80085");
    }  
} 
